package states;

import Ui.Btn;
import data.Chart;
import data.Songs;
import flixel.FlxG;
import flixel.FlxSprite;
import flixel.FlxState;
import flixel.graphics.frames.FlxAtlasFrames;
import flixel.group.FlxGroup;
import flixel.input.keyboard.FlxKey;
import flixel.sound.FlxSound;
import flixel.text.FlxText;
import net.Net;
import objects.Character;
import objects.Note;
import objects.Receptor;

class PlayState extends FlxState
{
	// ---- parametros (preenchidos antes de trocar de state) ----
	public static var song:String = "bopeebo";
	public static var diff:String = "normal";
	public static var online:Bool = false;
	public static var oppName:String = "CPU";
	public static var oppSkin:String = "dad";

	public static function setup(song:String, online:Bool, oppName:String, oppSkin:String, ?diff:String):Void
	{
		PlayState.song = song;
		PlayState.online = online;
		PlayState.oppName = oppName;
		PlayState.oppSkin = oppSkin;
		PlayState.diff = (diff == null) ? "normal" : diff;
	}

	// ---- layout (tela 1280x720) ----
	static inline var NOTE_SCALE:Float = 0.75;
	static inline var LANE_GAP:Float = 125;
	static inline var BASE_X:Float = 394;
	static inline var STRUM_Y:Float = 50;
	static inline var GROUND_Y:Float = 690;
	static inline var SPEED_MUL:Float = 2.0; // chart speed 1 => 0.9 px/ms
	static inline var MISS_MS:Float = 166;
	static inline var LEAD_MS:Float = 3000;

	var chart:Chart;
	var inst:FlxSound;
	var voices:FlxSound;
	var songPos:Float = -LEAD_MS;
	var started:Bool = false;
	var finished:Bool = false;
	var pps:Float; // pixels por ms
	var crochet:Float = 600;
	var lastBeat:Int = -999;

	var noteFrames:FlxAtlasFrames;
	var sustainGroup:FlxGroup;
	var noteGroup:FlxGroup;
	var active:Array<Note> = [];
	var si:Int = 0;
	var oi:Int = 0;

	var strums:Array<Receptor> = [];
	var oppStrums:Array<Receptor> = [];
	var oppTimers:Array<Float> = [0, 0, 0, 0];
	var held:Array<Bool> = [false, false, false, false];
	var glow:Array<FlxSprite> = [];

	var me:Character;
	var opp:Character;

	var score:Int = 0;
	var combo:Int = 0;
	var misses:Int = 0;
	var accPts:Float = 0;
	var judged:Int = 0;
	var oppScore:Int = 0;
	var oppGone:Bool = false;

	var hud:FlxText;
	var oppHud:FlxText;
	var judgeText:FlxText;
	var countText:FlxText;
	var banner:FlxText;
	var exitBtn:Btn;
	var lastCount:Int = 99;

	static var DIRS:Array<String> = ["LEFT", "DOWN", "UP", "RIGHT"];
	static var JUDGE:Array<String> = ["SICK!", "GOOD", "BAD", "SHIT", "MISS"];
	static var JCOLOR:Array<Int> = [0xFF66CCFF, 0xFF66FF66, 0xFFFFCC33, 0xFFFF6644, 0xFFFF3333];
	static var JSCORE:Array<Int> = [350, 200, 100, 50];
	static var JACC:Array<Float> = [1, 0.75, 0.5, 0.25];

	override function create()
	{
		super.create();
		if (FlxG.sound.music != null)
			FlxG.sound.music.stop();

		chart = Chart.load(song, diff);
		var info = Songs.info(song);
		crochet = 60000 / info.bpm;
		pps = 0.45 * chart.speed * SPEED_MUL;

		// cenario simples
		var back = new FlxSprite(0, 0, "assets/images/stages/default/stageback.png");
		back.setGraphicSize(FlxG.width, 700);
		back.updateHitbox();
		add(back);
		var front = new FlxSprite(0, 430, "assets/images/stages/default/stagefront.png");
		front.setGraphicSize(FlxG.width, 290);
		front.updateHitbox();
		add(front);

		opp = new Character(oppSkin, false, GROUND_Y, 280);
		add(opp);
		me = new Character(Settings.skin, true, GROUND_Y, 1020);
		add(me);

		// receptores do jogador (centro) e mini receptores do oponente (esquerda)
		noteFrames = Paths.atlas("game/notes/default");
		for (i in 0...4)
		{
			var g = new FlxSprite(BASE_X + i * LANE_GAP, 0).makeGraphic(118, FlxG.height, 0xFFFFFFFF);
			g.alpha = 0;
			glow.push(g);
			add(g);
		}
		for (i in 0...4)
		{
			var r = new Receptor(BASE_X + i * LANE_GAP, STRUM_Y, i, NOTE_SCALE, noteFrames);
			strums.push(r);
			add(r);
			var o = new Receptor(30 + i * 56, 24, i, 0.35, noteFrames);
			oppStrums.push(o);
			add(o);
		}
		sustainGroup = new FlxGroup();
		noteGroup = new FlxGroup();
		add(sustainGroup);
		add(noteGroup);

		// HUD
		hud = Ui.text(0, FlxG.height - 46, FlxG.width, "", 28, FlxTextAlign.CENTER);
		add(hud);
		oppHud = Ui.text(24, 90, 400, "", 24);
		add(oppHud);
		judgeText = Ui.text(0, 330, FlxG.width, "", 54, FlxTextAlign.CENTER);
		judgeText.alpha = 0;
		add(judgeText);
		countText = Ui.text(0, 250, FlxG.width, "", 110, FlxTextAlign.CENTER);
		add(countText);
		banner = Ui.text(0, 200, FlxG.width, "", 34, FlxTextAlign.CENTER, 0xFFFFE066);
		add(banner);
		exitBtn = new Btn(FlxG.width - 150, 10, 140, 50, "SAIR", 26, 0xFF8E2A2A);
		add(exitBtn);

		// audio
		inst = FlxG.sound.load(Paths.songFile(song, "Inst"));
		inst.onComplete = finish;
		if (Paths.exists(Paths.songFile(song, "Voices")))
			voices = FlxG.sound.load(Paths.songFile(song, "Voices"));

		if (online)
		{
			Net.onOpp = onOppMsg;
			Net.onOppLeft = function()
			{
				oppGone = true;
				banner.text = "Oponente saiu";
			};
			Net.onResult = onResult;
		}
		updateHud();
	}

	// ---------------------------------------------------------------- loop

	override function update(elapsed:Float)
	{
		super.update(elapsed);

		if (Ui.backPressed() || exitBtn.tapped())
		{
			leave();
			return;
		}
		if (finished)
			return;

		songPos += elapsed * 1000;
		if (!started)
		{
			updateCountdown();
			if (songPos >= 0)
				startSong();
		}
		else if (inst.playing && Math.abs(inst.time - songPos) > 50)
			songPos = inst.time;

		spawnNotes();
		pollInput();
		updateNotes(elapsed);
		updateOpponent();
		updateBeat();
		updateHud();

		if (judgeText.alpha > 0)
			judgeText.alpha -= elapsed * 2.2;
	}

	function startSong():Void
	{
		started = true;
		countText.text = "";
		inst.play();
		if (voices != null)
			voices.play();
		songPos = 0;
	}

	function updateCountdown():Void
	{
		var n = Math.ceil(-songPos / 1000); // 3,2,1,0
		if (n == lastCount)
			return;
		lastCount = n;
		if (n >= 1 && n <= 3)
		{
			countText.text = Std.string(n);
			FlxG.sound.play(Paths.sound("intro" + n));
		}
		else
		{
			countText.text = "GO!";
			FlxG.sound.play(Paths.sound("introGo"));
		}
	}

	function updateBeat():Void
	{
		var b = Math.floor(songPos / crochet);
		if (b != lastBeat)
		{
			lastBeat = b;
			if (b % 2 == 0)
			{
				me.dance();
				opp.dance();
			}
		}
	}

	function updateHud():Void
	{
		var total = judged > 0 ? Math.round(accPts / judged * 1000) / 10 : 100;
		hud.text = "Pontos: " + score + "   Combo: " + combo + "   Acerto: " + total + "%   Erros: " + misses;
		oppHud.text = (online ? oppName + ": " + oppScore : "");
	}

	// ---------------------------------------------------------------- notas

	function spawnNotes():Void
	{
		var ahead = (FlxG.height - STRUM_Y + 100) / pps;
		while (si < chart.player.length && chart.player[si].time - songPos < ahead)
		{
			var d = chart.player[si++];
			var n = new Note(d, noteFrames, BASE_X + d.lane * LANE_GAP, NOTE_SCALE);
			if (n.tail != null)
			{
				sustainGroup.add(n.tail);
				sustainGroup.add(n.cap);
			}
			noteGroup.add(n);
			active.push(n);
		}
	}

	function removeNote(n:Note):Void
	{
		active.remove(n);
		noteGroup.remove(n, true);
		n.destroy();
		if (n.tail != null)
		{
			sustainGroup.remove(n.tail, true);
			sustainGroup.remove(n.cap, true);
			n.tail.destroy();
			n.cap.destroy();
		}
	}

	function updateNotes(elapsed:Float):Void
	{
		var i = active.length;
		while (i-- > 0)
		{
			var n = active[i];
			var dt = n.time - songPos;
			var half = n.height / 2;

			if (n.holding)
			{
				var end = n.time + n.len;
				if (!held[n.lane] && songPos < end - 120)
				{
					removeNote(n); // soltou cedo
					continue;
				}
				if (songPos >= end)
				{
					strums[n.lane].play(held[n.lane] ? "confirm" : "static");
					removeNote(n);
					continue;
				}
				score += Std.int(elapsed * 1000 * 0.25);
				n.layoutTail(STRUM_Y + half, (end - songPos) * pps);
				if (strums[n.lane].animation.curAnim != null && strums[n.lane].animation.curAnim.finished)
					strums[n.lane].play("confirm");
				continue;
			}

			n.y = STRUM_Y + dt * pps;
			n.layoutTail(n.y + half, n.len * pps);

			if (!n.missed && -dt > MISS_MS)
				miss(n);

			if (n.y + n.height + n.len * pps + 80 < 0)
				removeNote(n);
		}
	}

	// ---------------------------------------------------------------- input

	function laneOf(sx:Float):Int
	{
		var l = 0;
		for (i in 0...3)
			if (sx > BASE_X + i * LANE_GAP + 59 + LANE_GAP / 2)
				l = i + 1;
		return l;
	}

	function pollInput():Void
	{
		var now = [false, false, false, false];
		if (FlxG.keys.anyPressed([FlxKey.LEFT, FlxKey.D, FlxKey.A]))
			now[0] = true;
		if (FlxG.keys.anyPressed([FlxKey.DOWN, FlxKey.F, FlxKey.S]))
			now[1] = true;
		if (FlxG.keys.anyPressed([FlxKey.UP, FlxKey.J, FlxKey.W]))
			now[2] = true;
		if (FlxG.keys.anyPressed([FlxKey.RIGHT, FlxKey.K, FlxKey.L]))
			now[3] = true;
		for (t in FlxG.touches.list)
			if (t.pressed)
				now[laneOf(t.screenX)] = true;

		for (l in 0...4)
		{
			glow[l].alpha = now[l] ? 0.18 : 0;
			if (now[l] && !held[l])
				press(l);
			else if (!now[l] && held[l])
				strums[l].play("static");
			held[l] = now[l];
		}
	}

	function press(lane:Int):Void
	{
		if (!started || finished)
			return;
		var best:Note = null;
		for (n in active)
			if (n.lane == lane && !n.hit && !n.missed && Math.abs(n.time - songPos) <= 135)
				if (best == null || Math.abs(n.time - songPos) < Math.abs(best.time - songPos))
					best = n;
		if (best != null)
			hitNote(best);
		else
			strums[lane].play("press"); // toque "no vazio": sem penalidade
	}

	function hitNote(n:Note):Void
	{
		var d = Math.abs(n.time - songPos);
		var r = d < 45 ? 0 : (d < 90 ? 1 : (d < 125 ? 2 : 3));
		n.hit = true;
		score += JSCORE[r];
		accPts += JACC[r];
		judged++;
		combo++;
		strums[n.lane].play("confirm");
		me.playAnim("sing" + DIRS[n.lane]);
		if (voices != null)
			voices.volume = 1;
		showJudge(r);
		sendNote(n.lane, r);
		if (n.len > 80)
		{
			n.holding = true;
			n.visible = false;
			n.y = STRUM_Y;
		}
		else
			removeNote(n);
	}

	function miss(n:Note):Void
	{
		n.missed = true;
		n.dim();
		combo = 0;
		misses++;
		judged++;
		score -= 10;
		me.playAnim("sing" + DIRS[n.lane] + "miss");
		if (voices != null)
			voices.volume = 0;
		FlxG.sound.play(Paths.sound("missnote" + FlxG.random.int(1, 3)), 0.4);
		showJudge(4);
		sendNote(n.lane, 4);
	}

	function showJudge(r:Int):Void
	{
		judgeText.text = JUDGE[r];
		judgeText.color = JCOLOR[r];
		judgeText.alpha = 1;
	}

	// ---------------------------------------------------------------- oponente

	function sendNote(lane:Int, r:Int):Void
	{
		if (online)
			Net.send({t: "n", lane: lane, r: r, score: score});
	}

	function oppSing(lane:Int, miss:Bool):Void
	{
		opp.playAnim("sing" + DIRS[lane] + (miss ? "miss" : ""));
		if (!miss)
		{
			oppStrums[lane].play("confirm");
			oppTimers[lane] = 0.15;
		}
	}

	function onOppMsg(m:Dynamic):Void
	{
		var r:Int = m.r;
		oppScore = m.score;
		oppSing(m.lane, r == 4);
	}

	function updateOpponent():Void
	{
		// offline: o CPU toca as notas do oponente do chart
		if (!online && started)
			while (oi < chart.opponent.length && chart.opponent[oi].time <= songPos)
				oppSing(chart.opponent[oi++].lane, false);

		for (l in 0...4)
			if (oppTimers[l] > 0)
			{
				oppTimers[l] -= FlxG.elapsed;
				if (oppTimers[l] <= 0)
					oppStrums[l].play("static");
			}
	}

	// ---------------------------------------------------------------- fim

	function finish():Void
	{
		if (finished)
			return;
		finished = true;
		inst.stop();
		if (voices != null)
			voices.stop();
		var acc = judged > 0 ? accPts / judged * 100 : 100;
		ResultsState.mine = {score: score, acc: acc, misses: misses};
		ResultsState.oppName = oppName;
		ResultsState.opp = null;
		if (online && !oppGone)
		{
			Net.send({t: "finish", score: score, acc: acc, misses: misses});
			banner.text = "Aguardando o oponente terminar...";
		}
		else
			FlxG.switchState(new ResultsState());
	}

	function onResult(m:Dynamic):Void
	{
		ResultsState.mine = {score: m.you.score, acc: m.you.acc, misses: m.you.misses};
		ResultsState.opp = {score: m.opp.score, acc: m.opp.acc, misses: m.opp.misses};
		FlxG.switchState(new ResultsState());
	}

	function leave():Void
	{
		if (online)
			Net.send({t: "leave"});
		inst.stop();
		if (voices != null)
			voices.stop();
		FlxG.switchState(new FreeplayState());
	}

	override function destroy()
	{
		Net.clearHandlers();
		super.destroy();
	}
}
