package states;

import flixel.FlxG;
import flixel.FlxSprite;
import flixel.FlxState;
import flixel.text.FlxText;
import flixel.util.FlxTimer;
import net.Net;

class MainMenuState extends FlxState
{
	var items:Array<FlxSprite> = [];
	var sel:Int = 0;
	var locked:Bool = false;
	var info:FlxText;

	override function create()
	{
		super.create();
		Ui.menuMusic();
		Net.connect();

		var bg = new FlxSprite(0, 0, Paths.img("menus/menuBG"));
		bg.setGraphicSize(FlxG.width, FlxG.height);
		bg.updateHitbox();
		add(bg);

		add(Ui.text(0, 24, FlxG.width, "FNF ONLINE", 72, FlxTextAlign.CENTER));

		var fp = new FlxSprite();
		fp.frames = Paths.atlas("menus/mainmenu/freeplay");
		fp.animation.addByPrefix("idle", "freeplay basic", 24, true);
		fp.animation.addByPrefix("sel", "freeplay white", 24, true);

		var sk = new FlxSprite();
		sk.frames = Paths.atlas("menus/mainmenu/skins");
		sk.animation.addByNames("idle", ["skins0", "skins1", "skins2"], 8, true);
		sk.animation.addByNames("sel", ["skins selected0", "skins selected1", "skins selected2"], 8, true);

		items = [fp, sk];
		for (i in 0...items.length)
		{
			var it = items[i];
			it.antialiasing = true;
			it.animation.play("idle");
			it.updateHitbox();
			it.screenCenter(X);
			it.y = 220 + i * 190 - it.height / 2;
			add(it);
		}

		info = Ui.text(20, FlxG.height - 44, FlxG.width - 40, "", 26);
		add(info);
		refreshInfo();
		highlight();
	}

	function refreshInfo():Void
	{
		info.text = "Jogador: " + Settings.name + "   Skin: " + Settings.skin + "   Servidor: " + Net.status;
	}

	function highlight():Void
	{
		for (i in 0...items.length)
			items[i].animation.play(i == sel ? "sel" : "idle");
	}

	override function update(elapsed:Float)
	{
		super.update(elapsed);
		refreshInfo();
		if (locked)
			return;

		if (FlxG.keys.justPressed.UP || FlxG.keys.justPressed.W)
			move(-1);
		if (FlxG.keys.justPressed.DOWN || FlxG.keys.justPressed.S)
			move(1);
		if (FlxG.keys.justPressed.ENTER || FlxG.keys.justPressed.SPACE)
			accept();

		if (FlxG.mouse.justPressed)
			for (i in 0...items.length)
				if (FlxG.mouse.overlaps(items[i]))
				{
					sel = i;
					highlight();
					accept();
				}
	}

	function move(d:Int):Void
	{
		sel = (sel + d + items.length) % items.length;
		FlxG.sound.play("assets/sounds/menu/scroll.ogg");
		highlight();
	}

	function accept():Void
	{
		locked = true;
		FlxG.sound.play("assets/sounds/menu/confirm.ogg");
		new FlxTimer().start(0.4, function(_)
		{
			if (sel == 0)
				FlxG.switchState(new FreeplayState());
			else
				FlxG.switchState(new SkinState());
		});
	}
}
