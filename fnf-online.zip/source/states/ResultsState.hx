package states;

import flixel.FlxG;
import flixel.FlxSprite;
import flixel.FlxState;
import flixel.text.FlxText;

typedef Result =
{
	var score:Int;
	var acc:Float;
	var misses:Int;
}

class ResultsState extends FlxState
{
	public static var mine:Result = {score: 0, acc: 0, misses: 0};
	public static var opp:Result = null;
	public static var oppName:String = "CPU";

	override function create()
	{
		super.create();
		Ui.menuMusic();
		var bg = new FlxSprite(0, 0, Paths.img("menus/menuBGBlue"));
		bg.setGraphicSize(FlxG.width, FlxG.height);
		bg.updateHitbox();
		add(bg);

		var title = "FIM DA MUSICA";
		if (opp != null)
			title = mine.score > opp.score ? "VOCE VENCEU!" : (mine.score < opp.score ? "VOCE PERDEU" : "EMPATE");
		add(Ui.text(0, 60, FlxG.width, title, 72, FlxTextAlign.CENTER, 0xFFFFE066));

		add(Ui.text(120, 220, 500, "VOCE\n" + line(mine), 36));
		if (opp != null)
			add(Ui.text(680, 220, 500, oppName + "\n" + line(opp), 36));
		else
			add(Ui.text(680, 220, 500, "(sem oponente)", 30));

		add(Ui.text(0, FlxG.height - 90, FlxG.width, "Toque para voltar", 32, FlxTextAlign.CENTER));
	}

	static function line(r:Result):String
		return "Pontos: " + r.score + "\nAcerto: " + (Math.round(r.acc * 10) / 10) + "%\nErros: " + r.misses;

	override function update(elapsed:Float)
	{
		super.update(elapsed);
		if (FlxG.mouse.justPressed || FlxG.keys.justPressed.ENTER || Ui.backPressed())
			FlxG.switchState(new FreeplayState());
	}
}
