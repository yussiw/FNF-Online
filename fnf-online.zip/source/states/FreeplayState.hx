package states;

import Ui.Btn;
import data.Songs;
import flixel.FlxG;
import flixel.FlxSprite;
import flixel.FlxState;
import flixel.group.FlxGroup;
import flixel.text.FlxText;
import net.Net;

typedef Hit =
{
	var bg:FlxSprite;
	var act:Void->Void;
}

/** Freeplay: musicas (treino offline ou criar sala) + partidas e jogadores online. */
class FreeplayState extends FlxState
{
	var status:FlxText;
	var dyn:FlxGroup;
	var back:Btn;
	var staticHits:Array<Hit> = [];
	var dynHits:Array<Hit> = [];

	override function create()
	{
		super.create();
		Ui.menuMusic();
		Net.connect();

		var bg = new FlxSprite(0, 0, Paths.img("menus/menuBGBlue"));
		bg.setGraphicSize(FlxG.width, FlxG.height);
		bg.updateHitbox();
		add(bg);

		back = new Btn(20, 20, 170, 56, "VOLTAR", 28);
		add(back);
		add(Ui.text(210, 22, 600, "FREEPLAY", 56));
		status = Ui.text(640, 90, 620, "", 24, FlxTextAlign.RIGHT);
		add(status);

		add(Ui.text(40, 130, 560, "MUSICAS", 36, FlxTextAlign.LEFT, 0xFFFFE066));
		var songs = Songs.all();
		for (i in 0...songs.length)
		{
			var s = songs[i];
			var y = 185 + i * 110;
			var row = new FlxSprite(40, y).makeGraphic(560, 90, 0xAA10182E);
			add(row);
			add(Ui.text(56, y + 24, 260, s.name, 34));
			var treino = new Btn(310, y + 15, 120, 60, "TREINO", 24);
			var sala = new Btn(445, y + 15, 140, 60, "SALA", 24, 0xFF2E7D32);
			add(treino);
			add(sala);
			staticHits.push({bg: treino.bg, act: function() startPractice(s.id)});
			staticHits.push({bg: sala.bg, act: function() createRoom(s.id)});
		}

		dyn = new FlxGroup();
		add(dyn);

		Net.onLobby = refresh;
		Net.onStart = function(m:Dynamic)
		{
			PlayState.setup(m.song, true, m.opp.name, m.opp.skin, m.diff);
			FlxG.switchState(new PlayState());
		};
		refresh();
	}

	function startPractice(song:String):Void
	{
		PlayState.setup(song, false, "CPU", "dad", "normal");
		FlxG.switchState(new PlayState());
	}

	function createRoom(song:String):Void
	{
		if (!Net.connected)
		{
			status.text = "Sem conexao com o servidor";
			return;
		}
		Net.send({t: "create", song: song});
	}

	function refresh():Void
	{
		status.text = "Servidor: " + Net.status;
		dyn.forEach(function(o) o.destroy());
		dyn.clear();
		dynHits = [];

		dyn.add(Ui.text(660, 130, 560, "PARTIDAS", 36, FlxTextAlign.LEFT, 0xFFFFE066));
		if (!Net.connected)
		{
			dyn.add(Ui.text(660, 185, 580, "Offline. Toque aqui para reconectar.", 26));
			var b = new Btn(660, 235, 300, 60, "RECONECTAR", 26);
			dyn.add(b);
			dynHits.push({bg: b.bg, act: function() Net.reconnect()});
			return;
		}

		var shown = 0;
		for (r in Net.rooms)
		{
			if (shown >= 4)
				break;
			var y = 180 + shown * 72;
			var mine = (Net.myRoom != null && r.id == Net.myRoom);
			var row = new Btn(660, y, 580, 62, (mine ? "(sua sala) " : "") + r.host + " - " + r.song, 26, mine ? 0xFF555555 : 0xFF223355);
			dyn.add(row);
			var id:Int = r.id;
			dynHits.push({bg: row.bg, act: function()
			{
				if (!mine)
					Net.send({t: "join", room: id});
			}});
			shown++;
		}
		if (shown == 0)
			dyn.add(Ui.text(660, 185, 580, "Nenhuma sala aberta. Crie uma em SALA!", 24));

		dyn.add(Ui.text(660, 480, 560, "ONLINE (" + Net.players.length + ")", 32, FlxTextAlign.LEFT, 0xFFFFE066));
		var names:Array<String> = [];
		for (p in Net.players)
			names.push(p.name + (p.busy ? " (jogando)" : ""));
		dyn.add(Ui.text(660, 525, 580, names.slice(0, 6).join("\n"), 24));

		if (Net.myRoom != null)
		{
			dyn.add(Ui.text(40, 640, 800, "Aguardando oponente...", 34, FlxTextAlign.LEFT, 0xFFFFE066));
			var c = new Btn(860, 630, 260, 60, "CANCELAR", 26, 0xFF8E2A2A);
			dyn.add(c);
			dynHits.push({bg: c.bg, act: function() Net.send({t: "leave"})});
		}
	}

	override function update(elapsed:Float)
	{
		super.update(elapsed);
		if (Ui.backPressed() || back.tapped())
		{
			if (Net.myRoom != null)
				Net.send({t: "leave"});
			FlxG.switchState(new MainMenuState());
			return;
		}
		if (FlxG.mouse.justPressed)
		{
			for (h in staticHits.concat(dynHits))
				if (FlxG.mouse.overlaps(h.bg))
				{
					FlxG.sound.play("assets/sounds/menu/confirm.ogg", 0.6);
					h.act();
					break;
				}
		}
	}

	override function destroy()
	{
		Net.onLobby = null;
		Net.onStart = null;
		super.destroy();
	}
}
