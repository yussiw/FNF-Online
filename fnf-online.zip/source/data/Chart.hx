package data;

import haxe.Json;
import openfl.utils.Assets;

typedef NoteData =
{
	var time:Float; // ms
	var lane:Int; // 0 esq, 1 baixo, 2 cima, 3 dir
	var len:Float; // duracao do sustain em ms
}

/** Le charts no formato do Codename Engine (strumLines[].notes: {id, time, sLen}). */
class Chart
{
	public var speed:Float = 1;
	public var player:Array<NoteData> = [];
	public var opponent:Array<NoteData> = [];

	public function new() {}

	public static function load(song:String, diff:String):Chart
	{
		var c = new Chart();
		var raw:Dynamic = Json.parse(Assets.getText('assets/songs/$song/charts/$diff.json'));
		if (raw.scrollSpeed != null)
			c.speed = raw.scrollSpeed;
		var lines:Array<Dynamic> = raw.strumLines;
		for (l in lines)
		{
			var type:Int = l.type;
			var notes:Array<Dynamic> = l.notes;
			for (n in notes)
			{
				var d:NoteData = {time: n.time, lane: n.id, len: n.sLen};
				if (type == 0)
					c.opponent.push(d);
				else if (type == 1)
					c.player.push(d);
			}
		}
		var cmp = function(a:NoteData, b:NoteData):Int return Std.int(a.time - b.time);
		c.player.sort(cmp);
		c.opponent.sort(cmp);
		return c;
	}
}
